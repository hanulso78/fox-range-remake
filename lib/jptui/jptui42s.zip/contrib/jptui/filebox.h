/****************************************************************************/
/* FILEBOX                                                                  */
/*--------------------------------------------------------------------------*/
/* File selection box                                                       */
/****************************************************************************/

#ifndef _FILEBOX_H_
#define _FILEBOX_H_

// Returns the full name of the selected file
// or "" if no file is selected

const char*	FileSelectionBox(const char* title, const char* mask,
		       				 const char* okButtonCaption = "",
		       				 const char* cancelButtonCaption = "");

#endif
