/****************************************************************************/
/* TEDZONE                                                                  */
/*--------------------------------------------------------------------------*/
/* Objet TEditZone (Zone d'�dition sur une ligne)                           */
/****************************************************************************/

#ifndef _TEDZONE_H_
#define _TEDZONE_H_

#include "Keyboard.h"
#include "Types.h"
#include "TObject.h"

// Vitesse de d�filement du texte

#define EDITZONE_FIRST_SCROLL_SPEED  150
#define EDITZONE_SCROLL_SPEED        70

class TEditZone:public TObject
{
  /*-----------------*/
  /* Champs prot�g�s */
  /*-----------------*/

  protected:

    // Longueur visible et longueur maximale du texte

    int     f_display_length,
	    f_max_length;

    // Modification du texte autoris�e

    bool f_modification_enabled;

    // V�rification de la validit� de la cha�ne active

    bool f_string_checking;

    // Longueur utile de la cha�ne (sans les . finaux)

    int     f_useful_length;

    // Cha�ne en cours de saisie (avec les . finaux)

    char    *f_string;

    // Cha�ne par d�faut (sans les .finaux)

    char    *f_default_string;

    // Message affich� si la saisie est invalide

    char    *f_error_message;


    // Mode insertion/recouvrement
    // (champ commun � toutes les instances de l'objet)

    static
    bool f_insert_mode;

    // Position du titre par rapport au texte

    int     f_xoffset_caption,
	    f_yoffset_caption;

    // Indice de cha�ne du premier caract�re visible

    int     f_first_visible_char;

    // Une zone est s�lectionn�e ?

    bool f_zone_selected;

    // Si oui :
    // -> caract�res de position min et max de la zone s�lectionn�e

    int     f_min_selected_char;
    int     f_max_selected_char;

    // En cours de s�lection :
    // -> premier et dernier caract�res s�lectionn�es
    //    (par ordre de s�lection)

    int     f_first_selected_char;
    int     f_last_selected_char;

    // Position du cursor (indice dans la cha�ne -> 0..f_useful_length)

    int     f_cursor_position;

    // Donn�es au moment o� la zone de saisie prend le focus

    char    *f_string_before_focus;      // Cha�ne avant modification
                                         // (sans les . finaux)

    // Cha�ne pour annulation par ALT_BACKSPACE

    char    *f_undo_string;
    bool  f_undo_string_can_change;

    // Cha�ne retourn�e par m_get_string (sans les . finaux)

    char    *f_return_string;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

     	            TEditZone(PObject parent,
		              int rel_x, int rel_y,
                              int xoffset_caption, int yoffset_caption,
			      const char *caption,
                              int display_length,
			      int max_length,
			      const char *string = "",
			      bool enabled=true);
    virtual         ~TEditZone();

    // M�thodes d'acc�s

	    void    m_set_cursor_at(int char_nb);

    virtual void    m_enable_modification()    {f_modification_enabled=true;};
    virtual void    m_disable_modification()   {f_modification_enabled=false;};

    virtual void    m_enable_string_checking() {f_string_checking=true;};
    virtual void    m_disable_string_checking(){f_string_checking=false;};

	    void    m_select_zone(int position1,int position2);
	    void    m_select_all()       {m_select_zone(0,f_useful_length);};
	    void    m_unselect();
            void    m_clear_selection();

    virtual void    m_set_string(const char *string);

    // La cha�ne peut �tre manipul�e tant que l'objet existe

	    char    *m_get_string();
	    int     m_get_string_length() { return(f_useful_length);};

    // Validit� d'une cha�ne pour la zone

    virtual bool m_string_valid(const char *string);

    // La zone peut-elle perdre le focus
    // (si non, affiche une boite de dialogue)

    virtual bool m_can_lose_focus();



    // Callback : Fonction appel�e � chaque modification de la cha�ne
    //            et son argument
	jptui::CallbackHolder	stringChangedAction_;

            void set_password_mode(bool a_mode) 
            {
              in_password_mode = a_mode; 
              m_display_string();
            }; 

  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

  protected:

    // Affichage

    virtual void    m_display();
    virtual void    m_display_focus_depending_part();
    virtual void    m_display_caption();
    virtual void    m_display_string();

    // Prise/Perte du focus

    virtual void    m_lose_focus();
    virtual void    m_take_focus();

    // L'objet devient actif/inactif

    virtual void    m_set_active(bool active);

    // Ev�nements

    virtual bool m_left_button_pressed_event(int x,int y);
    virtual bool m_left_button_double_click_event(int x,int y);
    virtual bool m_key_pressed_event(TKey key);

    // Caract�res saisis

	    void    m_character_hit(int character);

	    void    m_left_hit(bool shift_pressed);
	    void    m_right_hit(bool shift_pressed);
	    void    m_home_hit(bool shift_pressed);
	    void    m_end_hit(bool shift_pressed);
	    void    m_alt_backspace_hit();
	    void    m_backspace_hit();      // Annule les modifications
	    void    m_delete_hit();
	    void    m_insert_hit();

    // Appel des callbacks

    virtual void    m_string_modified_callback();


  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Calculs/Op�rations sur la cha�ne

	    void    m_calc_useful_length();
    virtual bool m_character_valid(int character);
    virtual const char *m_get_error_message();

    // D�placement du curseur

	    void    m_set_cursor_position(int cursor_position);
	    void    m_move_cursor_with_key_to(bool shift_pressed,int new_cursor_pos);

    // Rend le curseur visible

	    void    m_show_cursor();

    // Pour l'affichage
    bool in_password_mode; // to display every symbol as '*'

    virtual void    m_display_string_chars(unsigned background,int last_visible_char);

};

#endif
