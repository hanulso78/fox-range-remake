/****************************************************************************/
/* TRDIOGRP                                                                 */
/*--------------------------------------------------------------------------*/
/* Objet TRadioGroup (groupe de boutons radio)                              */
/****************************************************************************/

#ifndef _TRDIOGRP_H_
#define _TRDIOGRP_H_

#include "Types.h"

#include "TFrame.h"


class TRadioGroup:public TFrame
{
  /*----------------*/
  /* Friend classes */
  /*----------------*/

  friend class TRadioButton;

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Bouton radio du groupe qui est coch� (NULL si aucun)

    PRadioButton f_checked_radio_button;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur/Destructeur

		    TRadioGroup(PObject parent,
				int rel_x,int rel_y,
				int width,int height,
				char *caption="",
				bool enabled=true);

    virtual  	    ~TRadioGroup();

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Changement de bouton coch�

	    void m_change_checked_radio_button_to(int object_number);

    // Ev�nements

    virtual bool m_tab_pressed_event()  { return false; };
    virtual bool m_shift_tab_pressed_event() { return false; };


};

#endif
