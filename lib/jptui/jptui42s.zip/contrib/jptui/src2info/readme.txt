
Src2Info is a converter that translates the source files (.src) for
Jean-Pierre Delprat's JPTUI help files into texinfo/info files for the
GNU info program.


                   JPHC
 .src  ---------------------------> .hlp -------> jphelp

        src2info         makeinfo
 .src  ----------> .txi ----------> .inf -------> info


Src2Info uses GNU awk (gawk). You can find it in the djgpp/v2gnu directory
on SimTel mirrors, it's the archive gwk303b.zip.

The conversion process can be started either with the Src2Info.bat file
or with GNU make (3.76.1, other versions should do as well).

Src2Info.bat does the same as "make all" or just "make", i.e. it builds
the info files and leaves them in the current directory.

The info files are named jptui.inf, jptui.i1, jptui.i2 and so on.

The makefile uses GNU fileutils (fil316b.zip).

The makefile has five main targets:

1) "make all" or just "make" makes jptui.inf in the current directory.
   The *.src files must reside in the same directory.

2) "make view" invokes the info program to look at the jptui.i* files
   in the current directory.

3) "make install" copies the jptui.i* files to the djgpp/info directory
   and adds an appropriate menu entry to the dir file in that directory,
   so you can start "info jptui" afterwards.

4) "make dist" creates a subdirectory named src2info, copies all the
   source of src2info and packs them with Info-ZIP's zip.

5) "make clean" removes the intermediate files jptuisrc.all and
   jptui.txi.


Please send bug reports etc. to michael.mauch@gmx.de
(or michael.mauch@uni-duisburg.de, if GMX is down again).
