/****************************************************************************/
/* VOCAB                                                                    */
/*--------------------------------------------------------------------------*/
/* JPTui vocabulary functions                                               */
/****************************************************************************/

#ifndef _VOCAB_H_
#define _VOCAB_H_

#include "Types.h"

#include "JPVocab.h"

// Returns the current language

TLanguage GetLanguage();

// Loads vocabulary files specific to a language

bool   LoadVocabulary(TLanguage language);

// Removes vocabulary from memory

void      FreeVocabulary();

// Returns the chosen string in the current language

const char *GetString(int string_number);

#endif
