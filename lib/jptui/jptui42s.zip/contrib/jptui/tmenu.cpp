/****************************************************************************/
/* TMENU                                                                    */
/*--------------------------------------------------------------------------*/
/* Objet TMenu (menu d�roulant)                                             */
/*--------------------------------------------------------------------------*/
/* Auteur     : DELPRAT Jean-Pierre                                         */
/* Cr�� le    : 20/07/95                                                    */
/****************************************************************************/

#include <conio.h>
#include <stdlib.h>

#include "Const.h"

#include "JPAppli.h"

#include "Strings.h"
#include "TMenuBar.h"
#include "TWindow.h"

#include "TMenu.h"


/*������������������������������������������������������������������������ͻ*/
/*�                    PROPRIETES DES ELEMENTS DES MENUS                   �*/
/*������������������������������������������������������������������������ͼ*/

class TMenuItemProperties:public TListItemProperties
{
  public :

    int                 f_short_cut;
    char               *f_help_message;

			TMenuItemProperties(int short_cut, const char *help_message);
    virtual            ~TMenuItemProperties();
};

typedef TMenuItemProperties *PMenuItemProperties;

TMenuItemProperties::TMenuItemProperties(int short_cut, const char *help_message)
{
  f_short_cut=short_cut;

  f_help_message=new char [strlen(help_message)+1];
  strcpy(f_help_message,help_message);
}

TMenuItemProperties::~TMenuItemProperties()
{
  delete []f_help_message;
}

/*������������������������������������������������������������������������ͻ*/
/*�                           METHODES PUBLIQUES                           �*/
/*������������������������������������������������������������������������ͼ*/

/****************************************************************************/
/* Constructeur                                                             */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

TMenu::TMenu(PMenuBar menu_bar,
             const char *caption,
	     const TMenuItem items[],
	     bool enabled)
      :TList(NULL,
	     OBJ_MENU,
	     0,0,
	     0,0,
	     WHITE,
             caption,
             1,1,
	     0,0,
	     NOT_SORTED,
	     LI_DISABLED|LI_CHECKED|LI_TOGGLE,
	     false,  // not always one item selected
	     true,   // item hotkey enabled
	     false,  // No scroll bar
             0,0,0,
	     enabled),
		itemClickedAction_(this)
{
  // Couleur de la bordure de la fen�tre

  f_window->m_set_border_attr((WHITE<<4)+(unsigned)BLACK);

  // Barre de menus

  f_menu_bar=menu_bar;

  // Num�ro de menu (!= num�ro �l�ment

  f_menu_nb=menu_bar->m_add_menu(this);

  // Il faut recalculer la taille du menu

  f_size_to_adjust=false;

  // Largeur des shortcuts

  f_short_cut_width=0;

  // Ajout des �l�ments

  if (items!=NULL)
    m_add_items(items);
}

/****************************************************************************/
/* Destructeur                                                              */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

TMenu::~TMenu()
{
}

/****************************************************************************/
/* m_disable                                                                */
/*--------------------------------------------------------------------------*/
/* Rend l'objet inactivable                                                 */
/****************************************************************************/

void TMenu::m_disable()
{
  if (f_open)
    f_menu_bar->m_inactivate_menu_bar();

  TList::m_disable();
}

/****************************************************************************/
/* m_open                                                                   */
/*--------------------------------------------------------------------------*/
/* Opens the menu. Returns false if it can't be open.		            */
/****************************************************************************/

bool TMenu::m_open()
{
  if (f_open)
    return true;

  return(f_menu_bar->m_open_menu(f_menu_nb,true));
}

/****************************************************************************/
/* m_close                                                                  */
/*--------------------------------------------------------------------------*/
/* Closes the menu. 							    */
/****************************************************************************/

void TMenu::m_close()
{
  if (f_open)
    f_menu_bar->m_close_menu();
}

/****************************************************************************/
/* m_click_item                                                             */
/*--------------------------------------------------------------------------*/
/* Clique dans un item du menu                                              */
/****************************************************************************/

void TMenu::m_click_item(int item_index)
{
  // Le menu est inactif

  if (!f_enabled)
    return;

  // L'objet de la fen�tre poss�dant le focus ne veut pas le lacher

//  if (!f_window->m_can_lose_focus())
//    return;

  m_item_clicked_callback(item_index);
}

/*������������������������������������������������������������������������ͻ*/
/*�                          METHODES PROTEGEES                            �*/
/*������������������������������������������������������������������������ͼ*/

/**************************/
/* m_display : Affichage  */
/* ---------   de l'objet */
/**************************/

void TMenu::m_display()
{
  if (f_menu_bar->f_open)
    f_menu_bar->m_display_menu_caption(f_menu_nb);

  TList::m_display();
}

/****************************************************************************/
/* m_insert_item                                                            */
/*--------------------------------------------------------------------------*/
/* Ajout d'un �l�ment au menu.                                              */
/* Retourne son index ou 0 si l'ajout est impossible.                       */
/****************************************************************************/

int TMenu::m_insert_item(int index, const char *label,
			 int attribute, int short_cut,
                         const char *help_message)
{
  int item_nb;
  TMenuItemProperties *properties;

  // Le menu doit �tre ferm�

  if (f_open)
    return(0);

  // S�parateur -> short_cut=SC_NONE, pas de message d'aide

  if (!strcmp(SEPARATOR,label))
    {
      short_cut=SC_NONE;
      help_message="";
    }

  // Ajout

  properties=new TMenuItemProperties(short_cut,help_message);
  item_nb=TList::m_add_item_to_list(index,label,attribute,properties);

  return(item_nb);
}

/****************************************************************************/
/* m_add_items                                                              */
/*--------------------------------------------------------------------------*/
/* Ajout d'�l�ments au menu.                                                */
/* Chaque �l�ment est de type TMenuItem                                     */
/* Dans le dernier �l�ment, item[].label doit valoir NULL                   */
/* Retourne le nombre d'�l�ments effectivement ajout�                       */
/****************************************************************************/

int TMenu::m_add_items(const TMenuItem items[])
{
  register int nb_items;

  nb_items=0;
  while (items[nb_items].label!=NULL)
    {
      // Ajout d'un �l�ment

      if ((m_add_item(items[nb_items].label,
		      items[nb_items].attribute,
		      items[nb_items].short_cut,
		      items[nb_items].help_message))==0)
	break;   // Plus de place pour ajouter

      nb_items++;
   }

  return(nb_items);
}

/****************************************************************************/
/* m_delete_item                                                            */
/*--------------------------------------------------------------------------*/
/* Suppression d'un �l�ment de la liste.                                    */
/****************************************************************************/

void TMenu::m_delete_item(int item_index)
{
  // Le menu doit �tre ouvert

  if (f_open)
    return;

  // Suppression �l�ment

  TList::m_delete_item(item_index);

}

/****************************************************************************/
/* m_clear_list                                                             */
/*--------------------------------------------------------------------------*/
/* Efface la liste.                                                         */
/****************************************************************************/

void TMenu::m_clear_list()
{
  // Le menu doit �tre ouvert

  if (f_open)
    return;

  TList::m_clear_list();

}

/****************************************************************************/
/* m_selected_item_changed_callback                                         */
/*--------------------------------------------------------------------------*/
/* Fonction appel�e quand l'�l�ment s�lectionn� du menu est modifi�.        */
/****************************************************************************/

void TMenu::m_selected_item_changed_callback()
{
  PItemNode node;

  char *message="";

  if (f_selected_item_index!=0)
    {
      node=m_index_to_item(f_selected_item_index);
      if (node->properties!=NULL)
	message=PMenuItemProperties(node->properties)->f_help_message;
    }

  f_menu_bar->f_window->m_set_info_message(message);

  TList::m_selected_item_changed_callback();
}

/****************************************************************************/
/* m_nb_items_changed_callback                                              */
/*--------------------------------------------------------------------------*/
/* Fonction appel�e quand le nombre d'�l�ments de la liste est modifi�.     */
/****************************************************************************/

void TMenu::m_nb_items_changed_callback()
{
  f_size_to_adjust=true;
  TList::m_nb_items_changed_callback();
}

/****************************************************************************/
/* m_item_clicked_callback                                                  */
/*--------------------------------------------------------------------------*/
/* Callback associ� � un clic de l'un des �l�ments du menu                  */
/****************************************************************************/

void TMenu::m_item_clicked_callback(int item_index)
{
  if (m_item_is_enabled(item_index))
    {
      // El�ment de type TOGGLE ?

      if (m_item_attribute_is_set(item_index,LI_TOGGLE))
	{
	  if (!m_item_is_checked(item_index))
	    m_check_item(item_index);
	  else
	    m_uncheck_item(item_index);
	}

		itemClickedAction_(item_index);

    }
}

/****************************************************************************/
/* m_short_cut_pressed_event                                                */
/*--------------------------------------------------------------------------*/
/* Appel�e quand l'objet g�re les acc�l�rateurs de sa fen�tre.              */
/* Retourne true si l'acc�l�rateur int�resse l'objet                        */
/****************************************************************************/

bool TMenu::m_short_cut_pressed_event(int short_cut)
{
  register PItemNode node;
  register int       index;

  node=f_item_list;
  index=1;
  while (node!=NULL)
    {
      if ((((PMenuItemProperties)node->properties)->f_short_cut)==short_cut)
	{
	  m_click_item(index);
	  return true;
	}
      node=node->next;
      index++;
    }

  return false;
}


/*������������������������������������������������������������������������ͻ*/
/*�                            METHODES PRIVEES                            �*/
/*������������������������������������������������������������������������ͼ*/

/****************************************************************************/
/* m_display_item_node_label                                                */
/*--------------------------------------------------------------------------*/
/* Affiche un �l�ment de la liste d'apr�s un pointeur sur cet �l�ment       */
/* (la position d'affichage doit d�j� �tre fix�e ainsi que la couleur)      */
/* N'est pas appel� pour les s�parateurs                                    */
/****************************************************************************/

void TMenu::m_display_item_node_label(PItemNode node,bool show_hot_key)
{
  f_window->m_put_caption(node->label,
			  show_hot_key,
			  f_list_width-1-f_short_cut_width,
			  JUSTIFIED_LEFT);

  if (f_short_cut_width!=0)
    {
      f_window->m_putch(' ');
      f_window->m_put_caption(GetShortCutLabel(((PMenuItemProperties)node->properties)->f_short_cut),
			      false,
			      f_short_cut_width-1,
			      JUSTIFIED_LEFT);
    }
}


/****************************************************************************/
/* m_adjust_size                                                            */
/*--------------------------------------------------------------------------*/
/* Fixe la taille du menu, de la liste et de la fen�tre en fonction         */
/* des �l�ments du menu                                                     */
/****************************************************************************/

void TMenu::m_adjust_size()
{
  register PItemNode node;
  int                width,
		     height;
  register int       short_cut_length;
  int                temp;

  if (!f_size_to_adjust)
    return;

  f_size_to_adjust=false;

  // Taille du menu sans les short-cuts

  width=(f_nb_items==0)?0:m_get_list_needed_width();
  height=(f_nb_items==0)?0:f_nb_items;

  // Taille des short-cuts

  short_cut_length=0;
  node=f_item_list;
  while (node!=NULL)
    {
      temp=GetShortCutLabelLength(((PMenuItemProperties)node->properties)->f_short_cut);
      if (temp>=short_cut_length)
	short_cut_length=temp;
      node=node->next;
    }

  if (short_cut_length!=0)
    short_cut_length+=2;
  f_short_cut_width=short_cut_length;

  // Taille finale

  width+=short_cut_length;
  f_width=width+2;
  f_height=height+2;

  m_set_list_size(MAX(width,0),MAX(height,0));

  f_parent->m_set_size(f_width,f_height);
}

/****************************************************************************/
/* m_leave_event_if_mouse_leave_list                                        */
/*--------------------------------------------------------------------------*/
/* Appel�e dans l'�v�nement m_left_button_pressed_event lorsque la souris   */
/* quitte la zone de la liste.                                              */
/* Si true est retourn�e, l'�v�nement m_left_button_pressed_event est       */
/* interrompue                                                              */
/****************************************************************************/

bool TMenu::m_leave_event_if_mouse_leave_list(int x,int y)
{
  int x1=f_menu_bar->m_get_x();
  int x2=x1+f_menu_bar->f_width-1;
  int y1=f_menu_bar->m_get_y();

  if ((x>=x1) && (x<=x2) && (y==y1))
    return true;

  return false;
}

/****************************************************************************/
/* m_item_hot_key_pressed_event                                             */
/*--------------------------------------------------------------------------*/
/* Appel�e quand la hot-key d'un �l�ment actif a �t� press�e                */
/****************************************************************************/

void TMenu::m_item_hot_key_pressed_event(int item_index)
{
  f_menu_bar->m_inactivate_menu_bar();
  JPRefresh();

  m_item_clicked_callback(item_index);
}

