/****************************************************************************/
/* TTAB                                                                     */
/*--------------------------------------------------------------------------*/
/* Objet TTab (onglet)                                                      */
/****************************************************************************/

#ifndef _TTAB_H_
#define _TTAB_H_

#include "Types.h"

#include "TGroup.h"

class TTab:public TGroup
{
  /*---------------*/
  /* Classes amies */
  /*---------------*/

  friend class TTabGroup;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		    TTab(PTabGroup tab_group,
			 const char *caption);
    virtual  	    ~TTab();

    // M�thodes d'acc�s

    // Rend cet onglet visible

            void    m_set_visible();

    // Callback : Fonction appel�e lorsque l'onglet devient visible
    //            et son argument
	jptui::CallbackHolder	visibleAction_;

  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

  protected:


    // Affichage

    virtual void    m_display();
    virtual void    m_display_focus_depending_part();
    virtual void    m_display_caption();

    // Prise/Perte du focus

    virtual void    m_take_focus();

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

    // L'objet peut obtenir le focus lors d'un d�placement
    // avec les touches fl�ch�es

    virtual bool m_focus_can_be_set_by_arrow_key() { return true; };
};

#endif
