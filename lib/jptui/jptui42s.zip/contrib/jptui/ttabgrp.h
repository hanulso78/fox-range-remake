/****************************************************************************/
/* TTABGRP                                                                  */
/*--------------------------------------------------------------------------*/
/* Objet TTabGroup (Groupe d'onglets)                                       */
/****************************************************************************/

#ifndef _TTABGRP_H_
#define _TTABGRP_H_

#include "Types.h"

#include "Keyboard.h"

#include "TGroup.h"



class TTabGroup:public TGroup
{
  /*---------------*/
  /* Classes amies */
  /*---------------*/

  friend class TTab;

  /*---------------*/
  /* Champs priv�s */
  /*---------------*/

  private:

    // Nombre d'onglets en largeur

    int     f_nb_tabs_width;

    // Onglet visible

    PObjectNode
            f_visible_tab;

  /*-----------------*/
  /* Champs prot�g�s */
  /*-----------------*/

  protected:


  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		    TTabGroup(PObject parent,
			      int rel_x,int rel_y,
			      int width,int height,
			      unsigned background,
                              bool enabled=true);
    virtual         ~TTabGroup();

    // M�thodes d'acc�s

    // Donne le focus au groupe (au 1er/dernier de ses objets qui le veut)

    virtual bool m_set_focus();
    virtual bool m_set_focus_to_last_element();


  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

  protected:


    // Ajout d'un onglet

    virtual int     m_add_element(PObject object);
    virtual void    m_del_element(int object_number);

    // Ouverture/Fermeture du groupe

    virtual void    m_set_open(bool open);


    // Affichage

    virtual void    m_display();

    // Ev�nements

    virtual bool m_left_button_pressed_event(int x,int y);
    virtual bool m_left_button_double_click_event(int x,int y);
    virtual bool m_key_pressed_event(TKey key);

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Affichage

    virtual void    m_display_focus_depending_part();
            void    m_display_tab_caption(int tab_nb);

    // Donne le d�but et la largeur d'un des titres des onglets

            void    m_get_tab_caption_pos(int tab_nb,int &rel_x1,int &rel_x2);


    // Ev�nements

    virtual bool m_tab_pressed_event() { return false; };
    virtual bool m_shift_tab_pressed_event(){ return false; };

	    void    m_set_visible_tab(int tab_number);

    // L'objet peut obtenir le focus lors d'un d�placement
    // avec les touches fl�ch�es

    virtual bool m_focus_can_be_set_by_arrow_key() { return true; };
};

#endif
