/****************************************************************************/
/* TLABEL                                                                   */
/*--------------------------------------------------------------------------*/
/* Objet TLabel (Etiquette)                                                 */
/****************************************************************************/

#ifndef _TLABEL_H_
#define _TLABEL_H_

#include "Const.h"
#include "Types.h"

#include "TObject.h"

class TLabel:public TObject
{
  /*---------------*/
  /* Champs priv�s */
  /*---------------*/

  private:

    char *f_text;   // Texte � afficher

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

    // Constructeur / Destructeur

  public:
		    TLabel(PObject parent,
			   int rel_x,int rel_y,
			   const char *text);

		    TLabel(PObject parent,
			   int rel_x,int rel_y,
			   int width,int height,
			   const char *text="");

    virtual	    ~TLabel();

    // M�thodes d'acc�s

            void    m_set_text(const char *text);
	    char    *m_get_text() const {return(f_text);};

  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

  protected:

    // Affichage

    virtual void    m_display();

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

};

#endif
