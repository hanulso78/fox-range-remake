#include "Callback.hpp"
//#include "jpdebug.h"

using namespace	jptui;

//void	Callback::operator()(TObject* who, what_type what, item_type item)
//{/
//	JPDEBUG_STOP(0);
//}

Callback::~Callback()
{
}

CallbackHolder::CallbackHolder(TObject* who)
	:	who_(who),
		callback_(0)
{
}

void	CallbackHolder::set(Callback& callback, Callback::what_type what)
{
	callback_ = &callback;
	what_ = what;
}

void	CallbackHolder::unset()
{
	callback_ = 0;
}

bool	CallbackHolder::valid() const
{
	return callback_ != 0;
}

void	CallbackHolder::operator()(Callback::item_type item)
{
	if (valid()) {
		(*callback_)(who_, what_, item);
	}
}
