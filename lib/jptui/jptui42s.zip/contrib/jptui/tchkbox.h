/****************************************************************************/
/* TCHKBOX                                                                  */
/*--------------------------------------------------------------------------*/
/* Objet TCheckBox (Case � cocher)                                          */
/****************************************************************************/

#ifndef _TCHKBOX_H_
#define _TCHKBOX_H_

#include "Types.h"

#include "TObject.h"

class TCheckBox:public TObject
{
  /*-----------------*/
  /* Champs prot�g�s */
  /*-----------------*/

  protected:

    // CheckBox coch�e ou non

    bool f_checked;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		    TCheckBox(PObject parent,
			      int rel_x,int rel_y,
			      int width, const char *caption,
			      bool checked=false,
                              bool enabled=true);

    virtual         ~TCheckBox();

    // M�thodes d'acc�s

	    bool m_is_checked() { return(f_checked); };
    virtual void    m_check();
    virtual void    m_uncheck();

    // Callback : Fonction appel�e si on coche la checkbox
	//            et son argument
	jptui::CallbackHolder	checkedAction_;

    // Callback : Fonction appel�e si on d�coche la checkbox
    //            et son argument
	jptui::CallbackHolder	uncheckedAction_;

  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

    // La case � cocher est coch�e/d�coch�e

	    void    m_take_check();
	    void    m_lose_check();

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Affichage

    virtual void    m_display_focus_depending_part();
    virtual void    m_display_caption();

    // Ev�nements

    virtual bool m_left_button_pressed_event(int x,int y);
    virtual bool m_key_pressed_event(TKey key);
};

#endif
