/****************************************************************************/
/* FILEBOX                                                                  */
/*--------------------------------------------------------------------------*/
/* File selection box                                                       */
/****************************************************************************/

#ifndef _FILEBOX_H_
#define _FILEBOX_H_

// Returns the full name of the selected file
// or "" if no file is selected

char *FileSelectionBox(char *title,char *mask,
		       char *ok_button_caption="",
		       char *cancel_button_caption="");

#endif