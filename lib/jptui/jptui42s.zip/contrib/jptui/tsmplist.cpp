/****************************************************************************/
/* TSMPLIST                                                                 */
/*--------------------------------------------------------------------------*/
/* Objet TSimpleList (Liste dont les �l�ments n'ont pas de propri�t�s       */
/*                    suppl�mentaires)                                      */
/*--------------------------------------------------------------------------*/
/* Auteur     : DELPRAT Jean-Pierre                                         */
/* Cr�� le    : 13/05/96                                                    */
/****************************************************************************/

#include "TSmpList.h"

/*������������������������������������������������������������������������ͻ*/
/*�                           METHODES PUBLIQUES                           �*/
/*������������������������������������������������������������������������ͼ*/

/****************************************************************************/
/* Constructeur                                                             */
/*--------------------------------------------------------------------------*/
/* parent           : Objet auquel appartient l'objet                       */
/* rel_x,rel_y      : Coordonn�es de l'objet p/r au groupe                  */
/* width,height     : Dimensions de l'objet                                 */
/* caption          : L�gende de l'objet (hot-key pr�c�d� de ~)             */
/* list_rel_x,                                                              */
/* list_rel_y       : Position de la liste par rapport � l'objet            */
/* list_width,                                                              */
/* list_height      : Dimensions de la liste (le texte, sans les bordures)  */
/* items            : El�ments de la liste                                  */
/* enabled          : ENABLED si l'objet est activable (DISABLED sinon)     */
/* focus_depending..: L'aspect de l'objet d�pend du focus ou non            */
/****************************************************************************/

TSimpleList::TSimpleList(PObject parent,
			 int type,
			 int rel_x, int rel_y,
			 int width, int height,
			 unsigned background,
			 const char *caption,
			 int  list_rel_x,int list_rel_y,
			 int  list_width,
			 int  list_height,
			 bool sorted,
			 int     allowed_item_attribute,
			 bool always_one_item_selected,
			 bool item_hot_key_enabled,
			 bool scrollbar,
			 int     scrollbar_x,
			 int     scrollbar_y,
			 int     scrollbar_height,
			 bool enabled)
	    :TList(parent,
		   type,
		   rel_x,rel_y,
		   width,height,
		   background,
		   caption,
		   list_rel_x,list_rel_y,
		   list_width,list_height,
		   sorted,
		   allowed_item_attribute,
		   always_one_item_selected,
		   item_hot_key_enabled,
		   scrollbar,
		   scrollbar_x,
		   scrollbar_y,
		   scrollbar_height,
		   enabled)
{
}

/****************************************************************************/
/* Destructeur                                                              */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

TSimpleList::~TSimpleList()
{
}

/****************************************************************************/
/* m_add_items                                                              */
/*--------------------------------------------------------------------------*/
/* Ajout d'�l�ments � la liste.                                             */
/* Chaque �l�ment est de type TListItem                                     */
/* Dans le dernier �l�ment, item[].label doit valoir NULL                   */
/* Retourne le nombre d'�l�ments effectivement ajout�                       */
/****************************************************************************/

int TSimpleList::m_add_items(const TListItem items[])
{
  register int nb_items;

  nb_items=0;
  while (items[nb_items].label!=NULL)
    {
      // Ajout d'un �l�ment

      if (!m_add_item(items[nb_items].label,
		      items[nb_items].attribute))
	break;   // Plus de place pour ajouter

      nb_items++;
   }

  return(nb_items);
}


