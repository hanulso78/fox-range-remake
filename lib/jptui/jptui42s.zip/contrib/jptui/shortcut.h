/****************************************************************************/
/* SHORTCUT                                                                 */
/*--------------------------------------------------------------------------*/
/* Raccourcis clavier                                                       */
/****************************************************************************/

#ifndef _SHORTCUT_H_
#define _SHORTCUT_H_

#include "Keyboard.h"

/*������������������������������������������������������������������������ͻ*/
/*�                                CONSTANTES                              �*/
/*������������������������������������������������������������������������ͼ*/

#define SC_NONE		    0

#define SC_CTRL_A           CTRL_A
#define SC_CTRL_B           CTRL_B
#define SC_CTRL_C           CTRL_C
#define SC_CTRL_D           CTRL_D
#define SC_CTRL_E           CTRL_E
#define SC_CTRL_F           CTRL_F
#define SC_CTRL_G           CTRL_G
#define SC_CTRL_H           CTRL_H
#define SC_CTRL_I           CTRL_I
#define SC_CTRL_J           CTRL_J
#define SC_CTRL_K           CTRL_K
#define SC_CTRL_L           CTRL_L
#define SC_CTRL_M           CTRL_M
#define SC_CTRL_N           CTRL_N
#define SC_CTRL_O           CTRL_O
#define SC_CTRL_P           CTRL_P
#define SC_CTRL_Q           CTRL_Q
#define SC_CTRL_R           CTRL_R
#define SC_CTRL_S           CTRL_S
#define SC_CTRL_T           CTRL_T
#define SC_CTRL_U           CTRL_U
#define SC_CTRL_V           CTRL_V
#define SC_CTRL_W           CTRL_W
#define SC_CTRL_X           CTRL_X
#define SC_CTRL_Y           CTRL_Y
#define SC_CTRL_Z           CTRL_Z

#define SC_ALT_A            ALT_A
#define SC_ALT_B            ALT_B
#define SC_ALT_C            ALT_C
#define SC_ALT_D            ALT_D
#define SC_ALT_E            ALT_E
#define SC_ALT_F            ALT_F
#define SC_ALT_G            ALT_G
#define SC_ALT_H            ALT_H
#define SC_ALT_I            ALT_I
#define SC_ALT_J            ALT_J
#define SC_ALT_K            ALT_K
#define SC_ALT_L            ALT_L
#define SC_ALT_M            ALT_M
#define SC_ALT_N            ALT_N
#define SC_ALT_O            ALT_O
#define SC_ALT_P            ALT_P
#define SC_ALT_Q            ALT_Q
#define SC_ALT_R            ALT_R
#define SC_ALT_S            ALT_S
#define SC_ALT_T            ALT_T
#define SC_ALT_U            ALT_U
#define SC_ALT_V            ALT_V
#define SC_ALT_W            ALT_W
#define SC_ALT_X            ALT_X
#define SC_ALT_Y            ALT_Y
#define SC_ALT_Z            ALT_Z

#define SC_ALT_1            ALT_1
#define SC_ALT_2            ALT_2
#define SC_ALT_3            ALT_3
#define SC_ALT_4            ALT_4
#define SC_ALT_5            ALT_5
#define SC_ALT_6            ALT_6
#define SC_ALT_7            ALT_7
#define SC_ALT_8            ALT_8
#define SC_ALT_9            ALT_9
#define SC_ALT_0            ALT_0

#define SC_F1               F1
#define SC_F2               F2
#define SC_F3               F3
#define SC_F4               F4
#define SC_F5               F5
#define SC_F6               F6
#define SC_F7               F7
#define SC_F8               F8
#define SC_F9               F9
#define SC_F10              F10
#define SC_F11              F11
#define SC_F12              F12

#define SC_CTRL_F1          CTRL_F1
#define SC_CTRL_F2          CTRL_F2
#define SC_CTRL_F3          CTRL_F3
#define SC_CTRL_F4          CTRL_F4
#define SC_CTRL_F5          CTRL_F5
#define SC_CTRL_F6          CTRL_F6
#define SC_CTRL_F7          CTRL_F7
#define SC_CTRL_F8          CTRL_F8
#define SC_CTRL_F9          CTRL_F9
#define SC_CTRL_F10         CTRL_F10
#define SC_CTRL_F11         CTRL_F11
#define SC_CTRL_F12         CTRL_F12

#define SC_SHIFT_F1         SHIFT_F1
#define SC_SHIFT_F2         SHIFT_F2
#define SC_SHIFT_F3         SHIFT_F3
#define SC_SHIFT_F4         SHIFT_F4
#define SC_SHIFT_F5         SHIFT_F5
#define SC_SHIFT_F6         SHIFT_F6
#define SC_SHIFT_F7         SHIFT_F7
#define SC_SHIFT_F8         SHIFT_F8
#define SC_SHIFT_F9         SHIFT_F9
#define SC_SHIFT_F10        SHIFT_F10
#define SC_SHIFT_F11        SHIFT_F11
#define SC_SHIFT_F12        SHIFT_F12

#define SC_ALT_F1    	    ALT_F1
#define SC_ALT_F2           ALT_F2
#define SC_ALT_F3           ALT_F3
#define SC_ALT_F4           ALT_F4
#define SC_ALT_F5           ALT_F5
#define SC_ALT_F6           ALT_F6
#define SC_ALT_F7           ALT_F7
#define SC_ALT_F8           ALT_F8
#define SC_ALT_F9           ALT_F9
#define SC_ALT_F10          ALT_F10
#define SC_ALT_F11          ALT_F11
#define SC_ALT_F12          ALT_F12

#define SC_HOME		    HOME
#define SC_PGUP             PGUP
#define SC_END              END
#define SC_PGDN             PGDN
#define SC_BACKSPACE        BACKSPACE
#define SC_INSERT           INSERT
#define SC_DELETE           DELETE

#define SC_CTRL_HOME	    CTRL_HOME
#define SC_CTRL_PGUP        CTRL_PGUP
#define SC_CTRL_END         CTRL_END
#define SC_CTRL_PGDN        CTRL_PGDN
#define SC_CTRL_BACKSPACE   CTRL_BACKSPACE
#define SC_CTRL_INSERT      CTRL_INSERT
#define SC_CTRL_DELETE      CTRL_DELETE

#define SC_CTRL_UP          CTRL_UP
#define SC_CTRL_DOWN        CTRL_DOWN
#define SC_CTRL_LEFT        CTRL_LEFT
#define SC_CTRL_RIGHT       CTRL_RIGHT

#define SC_SHIFT_INSERT     SHIFT_INSERT
#define SC_SHIFT_DELETE     SHIFT_DELETE

#define SC_ALT_HOME         ALT_HOME
#define SC_ALT_END          ALT_END
#define SC_ALT_BACKSPACE    ALT_BACKSPACE
#define SC_ALT_DELETE       ALT_DELETE

#define SC_CTRL_SHIFT_UP    CTRL_SHIFT_UP
#define SC_CTRL_SHIFT_DOWN  CTRL_SHIFT_DOWN
#define SC_CTRL_SHIFT_LEFT  CTRL_SHIFT_LEFT
#define SC_CTRL_SHIFT_RIGHT CTRL_SHIFT_RIGHT


/*������������������������������������������������������������������������ͻ*/
/*�                                FONCTIONS                               �*/
/*������������������������������������������������������������������������ͼ*/

char *GetShortCutLabel(int short_cut);
int  GetShortCutLabelLength(int short_cut);

#endif
