/****************************************************************************/
/* TRDIOBUT                                                                 */
/*--------------------------------------------------------------------------*/
/* Objet TRadioButton (bouton radio)                                        */
/****************************************************************************/

#ifndef _TRDIOBUT_H_
#define _TRDIOBUT_H_

#include "Const.h"
#include "Types.h"

#include "Keyboard.h"

#include "TChkBox.h"

class TRadioButton:public TCheckBox
{
  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		    TRadioButton(PRadioGroup radio_group,
				 int rel_x,int rel_y,
				 int width, const char *caption,
				 bool checked=false,
                                 bool enabled=true);
    virtual         ~TRadioButton();

    // M�thodes d'acc�s

    virtual void    m_check();
    virtual void    m_uncheck();

    // Affichage

    virtual void    m_display_focus_depending_part();
    virtual void    m_display_caption();

    // Ev�nements

    virtual bool m_left_button_pressed_event(int x,int y);
    virtual bool m_key_pressed_event(TKey key);

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:


};

#endif
