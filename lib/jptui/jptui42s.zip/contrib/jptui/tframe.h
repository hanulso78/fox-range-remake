/****************************************************************************/
/* TFRAME                                                                   */
/*--------------------------------------------------------------------------*/
/* Objet TFrame (Group d'objets entour�s d'un cadre)                        */
/****************************************************************************/

#ifndef _TFRAME_H_
#define _TFRAME_H_

#include "Types.h"

#include "TGroup.h"

class TFrame:public TGroup
{

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur/Destructeur

		    TFrame(PObject parent,
			   int rel_x, int rel_y,
			   int width,int height,
			   const char *caption = "",
			   bool enabled=true);
    virtual         ~TFrame();

    // Fix: frame color redefinition
    void	     set_frame_color(unsigned a_color) 
      { frame_color = a_color; };

  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

  protected:

    // Affichage

    virtual void    m_display_caption();

    // Fix: added frame color to be able to redefine
    unsigned	    frame_color;	
};


#endif
