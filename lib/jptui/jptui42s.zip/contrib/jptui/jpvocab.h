/****************************************************************************/
/* JPVOCAB                                                                  */
/*--------------------------------------------------------------------------*/
/* Strings used by JPTUI					            */
/*--------------------------------------------------------------------------*/
/* These strings, available in several languages, can be found in the       */
/* following data files :						    */
/* - JPVOCAB.ENG : English strings                                          */
/* - JPVOCAB.FRE : French strings                                           */
/* - JPVOCAB.GER : German strings                                           */
/* - JPVOCAB.ITA : Italian strings                                          */
/* - JPVOCAB.SPA : Spanish strings                                          */
/* -  ...                                                                   */
/* These data files are archived in JPTUI.DAT                               */
/****************************************************************************/

#ifndef _JPVOCAB_H_
#define _JPVOCAB_H_


#define VOC_VGA_CARD_NEEDED                    0
#define VOC_MOUSE_DRIVER_NOT_INSTALLED         1

#define VOC_CTRL                              10
#define VOC_ALT                               11
#define VOC_SHIFT                             12
#define VOC_HOME                              13
#define VOC_PGUP                              14
#define VOC_END                               15
#define VOC_PGDN                              16
#define VOC_BACKSPACE                         17
#define VOC_INSERT                            18
#define VOC_DELETE                            19
#define VOC_CTRL_SHIFT                        20

#define VOC_INDEX			      30

#define VOC_OK_CAPTION                        50
#define VOC_CANCEL_CAPTION                    51
#define VOC_QUIT_CAPTION                      52
#define VOC_YES_CAPTION                       53
#define VOC_NO_CAPTION                        54
#define VOC_ABORT_CAPTION                     55
#define VOC_RETRY_CAPTION                     56
#define VOC_IGNORE_CAPTION                    57
#define VOC_CONTINUE_CAPTION                  58
#define VOC_YES_TO_ALL_CAPTION                59
#define VOC_REVIEW_CAPTION		      60

#define VOC_FILENAME_CAPTION                  70
#define VOC_SEARCH_CAPTION                    71
#define VOC_OPEN_DIRECTORY_CAPTION            72

#define VOC_CONTENTS_CAPTION		      80
#define VOC_INDEX_CAPTION		      81
#define VOC_BACK_CAPTION		      82
#define VOC_PREVIOUS_CAPTION		      83
#define VOC_NEXT_CAPTION		      84

#define VOC_INVALID_ENTRY                    100
#define VOC_MUST_BE_DECIMAL_BETWEEN          101
#define VOC_MUST_BE_INTEGER_BETWEEN          102

#define VOC_DRIVE_DOESNT_EXIST               110
#define VOC_NO_DISK_IN_DRIVE                 111
#define VOC_INVALID_DIRECTORY                112
#define VOC_INVALID_FILE                     113

#define VOC_HELP_FILE_NOT_FOUND              120
#define VOC_INVALID_HELP_FILE		     121
#define VOC_HELP_TOPIC_NOT_FOUND             122

#endif
