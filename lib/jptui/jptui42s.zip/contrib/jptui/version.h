/*****************************************************************************/
/* VERSION                                                                   */
/*---------------------------------------------------------------------------*/
/* JPTUI Version                                                             */
/*---------------------------------------------------------------------------*/
/* Author      : DELPRAT Jean-Pierre                                         */
/*****************************************************************************/

#ifndef _VERSION_H_
#define _VERSION_H_

#define JPTUI_VERSION         4
#define JPTUI_SUB_VERSION     0
#define JPTUI_SUB_SUB_VERSION k

#define JPTUI_VERSION_STRING "4.2"
#define JPTUI_DATE_STRING    "13-DEC-2002"

// Don't forget to change JPTUI.DEF and the .DIZ files, Jean-Pierre

#endif
