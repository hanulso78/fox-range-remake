/****************************************************************************/
/* SPCHARS                                                                  */
/*--------------------------------------------------------------------------*/
/* Special chars of JPTUI (chars which depend on the font)  		    */
/*--------------------------------------------------------------------------*/
/* Author      : DELPRAT Jean-Pierre                                        */
/* Created on  : 01/15/97                                                   */
/****************************************************************************/


#include "SpChars.h"


TFont JPFont=FONT_JPTUI;

char JPSpecialChar[SCH_LAST][2]=
{
  { '�',CHAR_UP_LEFT_CORNER},      // SCH_WINDOW_UP_LEFT
  { '�',CHAR_UP_HLINE},            // SCH_WINDOW_UP
  { '�',CHAR_UP_RIGHT_CORNER},     // SCH_WINDOW_UP_RIGHT
  { '�',CHAR_LEFT_VLINE},          // SCH_WINDOW_LEFT
  { '�',CHAR_RIGHT_VLINE},         // SCH_WINDOW_RIGHT
  { '�',CHAR_BOTTOM_LEFT_CORNER},  // SCH_WINDOW_BOTTOM_LEFT
  { '�',CHAR_BOTTOM_HLINE},  	   // SCH_WINDOW_BOTTOM
  { '�',CHAR_BOTTOM_RIGHT_CORNER}, // SCH_WINDOW_BOTTOM_RIGHT


  { '�',CHAR_MIDDLE_RIGHT_CORNER}, // SCH_FRAME_UP_RIGHT
  { '�',CHAR_LEFT_VLINE },         // SCH_FRAME_LEFT
  { '�',CHAR_RIGHT_VLINE},         // SCH_FRAME_RIGHT
  { '�',CHAR_UP_HLINE},            // SCH_FRAME_BOTTOM_LEFT
  { '�',CHAR_UP_HLINE},            // SCH_FRAME_BOTTOM
  { '�',CHAR_UP_HLINE},            // SCH_FRAME_BOTTOM_RIGHT

  { '�',CHAR_BOTTOM_HLINE},        // SCH_TEXTZONE_UP_LEFT
  { '�',CHAR_BOTTOM_HLINE},        // SCH_TEXTZONE_UP
  { '�',CHAR_BOTTOM_HLINE},        // SCH_TEXTZONE_UP_RIGHT
  { '�',CHAR_LEFT_VLINE},          // SCH_TEXTZONE_LEFT
  { '�',CHAR_RIGHT_VLINE},         // SCH_TEXTZONE_RIGHT
  { '�',CHAR_UP_HLINE},            // SCH_TEXTZONE_BOTTOM_LEFT
  { '�',CHAR_UP_HLINE},            // SCH_TEXTZONE_BOTTOM
  { '�',CHAR_UP_HLINE},            // SCH_TEXTZONE_BOTTOM_RIGHT

  { '�',CHAR_UP_LEFT_CORNER},      // SCH_TABGROUP_UP_LEFT
  { '�',CHAR_UP_HLINE},            // SCH_TABGROUP_UP
  { '�',CHAR_UP_RIGHT_CORNER},     // SCH_TABGROUP_UP_RIGHT
  { '�',CHAR_LEFT_VLINE},          // SCH_TABGROUP_LEFT
  { '�',CHAR_RIGHT_VLINE},         // SCH_TABGROUP_RIGHT
  { '�',CHAR_BOTTOM_LEFT_CORNER},  // SCH_TABGROUP_BOTTOM_LEFT
  { '�',CHAR_BOTTOM_HLINE},  	   // SCH_TABGROUP_BOTTOM
  { '�',CHAR_BOTTOM_RIGHT_CORNER}, // SCH_TABGROUP_BOTTOM_RIGHT

  { '�',CHAR_LEFT_VLINE}, 	   // SCH_TAB_CAPTION_LEFT

  { '�',CHAR_BOTTOM_HLINE},        // SCH_LISTBOX_UP_LEFT
  { '�',CHAR_BOTTOM_HLINE},        // SCH_LISTBOX_UP
  { '�',CHAR_BOTTOM_HLINE},        // SCH_LISTBOX_UP_RIGHT
  { '�',CHAR_LEFT_VLINE},          // SCH_LISTBOX_LEFT
  { '�',CHAR_RIGHT_VLINE},         // SCH_LISTBOX_RIGHT
  { '�',CHAR_UP_HLINE},            // SCH_LISTBOX_BOTTOM_LEFT
  { '�',CHAR_UP_HLINE},            // SCH_LISTBOX_BOTTOM
  { '�',CHAR_UP_HLINE},            // SCH_LISTBOX_BOTTOM_RIGHT

  { '�',CHAR_UP_BOTTOM_HLINES},    // SCH_SHAFT_HORIZONTAL
  { '�',CHAR_UP_BOTTOM_HLINES},    // SCH_SLIDER_HORIZONTAL

  { '�',CHAR_UP_HLINE},	   	   // SCH_COMBOBOX_UP_RIGHT
  { '�',CHAR_BOTTOM_HLINE},	   // SCH_COMBOBOX_BOTTOM_RIGHT

  { '\x4',CHAR_TICK},		   // SCH_LIST_CHECK



};


char *JPSpecialString[SST_LAST][2]=
{
  { "\x18\x18",TEXT_ARROW_UP},           // SST_ARROW_UP
  { "\x19\x19",TEXT_ARROW_DOWN},         // SST_ARROW_DOWN
  { "\x1B\x1B",TEXT_ARROW_LEFT},         // SST_ARROW_LEFT
  { "\x1A\x1A",TEXT_ARROW_RIGHT},        // SST_ARROW_RIGHT

  { "��", TEXT_LEFT_VLINE
	  TEXT_RIGHT_VLINE},		 // SST_SHAFT_VERTICAL
  { "��", TEXT_LEFT_VLINE
	  TEXT_RIGHT_VLINE},		 // SST_SLIDER_VERTICAL

  { "[x]", TEXT_CHECKED_CHECK_BOX},      // SST_CHECKBOX_CHECKED
  { "[ ]", TEXT_UNCHECKED_CHECK_BOX},    // SST_CHECKBOX_UNCHECKED

  { "(\x7)", TEXT_CHECKED_RADIO_BUTTON}, // SST_RADIOBUTTON_CHECKED
  { "( )", TEXT_UNCHECKED_RADIO_BUTTON}, // SST_RADIOBUTTON_UNCHECKED

  { "[]", TEXT_CLOSE_BUTTON},		 // SST_WINDOW_CLOSE_BUTTON

  { "��",TEXT_BOTTOM_HLINE \
	 TEXT_BOTTOM_RIGHT_CORNER},      // SST_TEXTZONE_SB_CORNER

  { "����Ŀ\n"
    "�STOP�\n"
    "������",  TEXT_UP_LEFT_CORNER
	       TEXT_UP_HLINE
	       TEXT_UP_HLINE
	       TEXT_UP_HLINE
	       TEXT_UP_HLINE
	       TEXT_UP_RIGHT_CORNER
	       "\n"
	       TEXT_LEFT_VLINE
	       "STOP"
	       TEXT_RIGHT_VLINE
	       "\n"
	       TEXT_BOTTOM_LEFT_CORNER
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_RIGHT_CORNER},// SST_ICON_STOP


  { "�Ŀ\n"
    "�?�\n"
    "���",     TEXT_UP_LEFT_CORNER
	       TEXT_UP_HLINE
	       TEXT_UP_RIGHT_CORNER
	       "\n"
	       TEXT_LEFT_VLINE
	       "?"
	       TEXT_RIGHT_VLINE
	       "\n"
	       TEXT_BOTTOM_LEFT_CORNER
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_RIGHT_CORNER},// SST_ICON_QUESTION

  { "�Ŀ\n"
    "�!�\n"
    "���",     TEXT_UP_LEFT_CORNER
	       TEXT_UP_HLINE
	       TEXT_UP_RIGHT_CORNER
	       "\n"
	       TEXT_LEFT_VLINE
	       "!"
	       TEXT_RIGHT_VLINE
	       "\n"
	       TEXT_BOTTOM_LEFT_CORNER
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_RIGHT_CORNER},// SST_ICON_EXCLAMATION

  { "����Ŀ\n"
    "�Info�\n"
    "������",  TEXT_UP_LEFT_CORNER
	       TEXT_UP_HLINE
	       TEXT_UP_HLINE
	       TEXT_UP_HLINE
	       TEXT_UP_HLINE
	       TEXT_UP_RIGHT_CORNER
	       "\n"
	       TEXT_LEFT_VLINE
	       "Info"
	       TEXT_RIGHT_VLINE
	       "\n"
	       TEXT_BOTTOM_LEFT_CORNER
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_HLINE
	       TEXT_BOTTOM_RIGHT_CORNER},// SST_ICON_INFORMATION

};

