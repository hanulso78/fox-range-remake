/****************************************************************************/
/* SETTINGS                                                                 */
/*--------------------------------------------------------------------------*/
/* Directives de compilation de la librairie JPTUI                          */
/****************************************************************************/

#ifndef _SETTINGS_H_
#define _SETTINGS_H_


// Si NDEBUG est d�fini, les macros DEBUG ne font rien
// Sinon, elles permettent de faire des tests et d'arr�ter le programme.

//#define NDEBUG

#endif
