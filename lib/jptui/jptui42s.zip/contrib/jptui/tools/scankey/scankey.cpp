#include <stdio.h>

#include "..\..\Keyboard.h"

void GetMouseState(int &/*x*/,int &/*y*/,int &/*button_state*/)
{
}

int main()
{
  TKey key;

  GetKey(key);

  while (key.character!=ESC)
    {
      printf("%d %c %s\n",key.character,key.hot_character,(IsAltKey(key)?"ALT":"PAS ALT"));
      GetKey(key);
    }
  return(0);
}
