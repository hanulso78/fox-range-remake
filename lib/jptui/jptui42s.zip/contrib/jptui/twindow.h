/****************************************************************************/
/* TWINDOW                                                                  */
/*--------------------------------------------------------------------------*/
/* Objet TWindow (fen�tre)                                                  */
/****************************************************************************/

#ifndef _TWINDOW_H_
#define _TWINDOW_H_

#include <conio.h>

#include "Types.h"

#include "Keyboard.h"

#include "TGroup.h"


/*������������������������������������������������������������������������ͻ*/
/*�                                CONSTANTES                              �*/
/*������������������������������������������������������������������������ͼ*/

// Position d'une chaine dans sa zone d'affichage

#define CENTERED        0
#define JUSTIFIED_LEFT  1
#define JUSTIFIED_RIGHT 2

#define CENTERED_LEFT   4
#define CENTERED_RIGHT  5

// Types des fl�ches

#define ARROW_UP    0
#define ARROW_DOWN  1
#define ARROW_LEFT  2
#define ARROW_RIGHT 3

// Styles des fenetres

//#define DIALOG1 (LIGHTBLUE)
#define DIALOG1 (LIGHTBLUE + (LIGHTGREEN << TWINDOW_BRIGHT_ATTR_SHIFT))
#define DIALOG2 (LIGHTCYAN)
#define DIALOG3 (CYAN)

#define ALERT   (RED)
#define HELP    (GREEN)

// Fix: adding user defined colors
#define TWINDOW_COLOR_MASK	   0xF
#define TWINDOW_BRIGHT_ATTR_SHIFT  8
#define TWINDOW_NORMAL_ATTR_SHIFT  16

/*������������������������������������������������������������������������ͻ*/
/*�                         DEFINITION DE L'OBJET                          �*/
/*������������������������������������������������������������������������ͼ*/

class TWindow:public TGroup
{
  /*-------------*/
  /* Objets amis */
  /*-------------*/

  friend class TApplication;	// Pour que l'application facilement manipuler ses
								// fen�tres
  friend class TObject;       
  friend class TPushButton;		// Pour g�rer les boutons sp�ciaux

  /*------------------*/
  /* Protected fields */
  /*------------------*/

  protected:

    // Position de la fen�tre dans l'�cran (1...)

    int         f_x,
		f_y;

    // There is an information bar

    bool     f_info_bar;

    // Couleur d'affichage du titre quand il a le focus

    unsigned    f_title_attribute;

    // Couleur d'affichage de la bordure

    unsigned    f_border_attribute;

    // Fix: to redefine shadows type
protected: TShadowChoice shadows; 
public:    void 	 set_shadows(TShadowChoice a_shadows)
	   { shadows = a_shadows; };

  /*----------------*/
  /* Private fields */
  /*----------------*/

  private:

    // Num�ro de la fen�tre dans l'application

    int         f_window_number;

    // If the information bar exits, message it displays

    char        *f_info_message;

    // La fen�tre est modale

    bool     f_modal;

    // La fen�tre est d�pla�able

    bool     f_movable;

    // La fen�tre est active

    bool     f_active;

    // Objet qui g�re les acc�l�rateurs de la fen�tre

    PObject     f_short_cut_handler;

    // Boutons sp�ciaux de la fen�tre

    PPushButton f_default_button;  // Bouton par d�faut
    PPushButton f_ok_button;       // Bouton actuellement activable par RETURN
    PPushButton f_cancel_button;   // Bouton actuellement activable par ESC

    // Pour l'affichage dans la fen�tre
    // (n'appara�t � l'�cran qu'apr�s un rafra�chissement)

    word        *f_window_content; // Contenu de la fen�tre

    bool     f_content_changed; // Le contenu de la fen�tre a chang� depuis
				   // le dernier rafra�chissement

    TIntZone    f_changed_zone;    // si f_content_changed est true,
				   // zone de la fen�tre dont le contenu
				   // a �t� modifi� depuis le dernier rafra�chissement

    TIntZone    f_clip_window;     // Limites d'affichage du texte

    int         f_x_cursor;        // Coordonn�es du curseur de la fen�tre
    int         f_y_cursor;        // (position d'affichage, pas curseur �cran)
    word        *f_cursor_ptr;     // Pointeur sur le caract�re courant

    int         f_text_attribute;  // Attribut d'affichage

    // Objet de la fen�tre qui avait le focus avant que le focus ne change
    // d'objet dans la fen�tre

    PObject     f_previous_focused_object;

    // Callback : Fonction appel�e lorsque l'on clique sur l'icone de
    //            fermeture de la fen�tre
    //            et son argument
	jptui::CallbackHolder	closeButtonPressedAction_;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		     TWindow(unsigned style,
			     int x, int y,
			     int width, int height,
			     const char *caption = "",
			     bool info_bar=false,
			     bool modal=true,
			     bool movable=true);

    virtual  	     ~TWindow();

    // M�thodes d'acc�s

    virtual int      m_get_x()  { return (f_x); };
    virtual int      m_get_y()  { return (f_y); };

	    void     m_set_pos(int x,int y);

	    void     m_set_title_attr(unsigned attribute) {f_title_attribute=attribute;};
	    void     m_set_border_attr(unsigned attribute) {f_border_attribute=attribute;};

	    void     m_set_short_cut_handler(PObject handler) {f_short_cut_handler=handler;};
	    void     m_set_default_button(PPushButton button);
	    void     m_set_cancel_button(PPushButton button);

    // Donne le focus � la fen�tre (au 1er/dernier de ses objets qui le veut)
    // Sinon, la fen�tre seul (aucun objet) prend le focus

    virtual bool  m_set_focus();
    virtual bool  m_set_focus_to_last_element();

    // Retourne l'objet de la fen�tre qui avait le focus
    // avant que celui ne change d'objet

	    PObject  m_get_previous_focused_object() {return(f_previous_focused_object);};

    // Rend la fen�tre active

	    bool  m_activate();
	    bool  m_is_active() {return(f_active);};

    // Ouverture/Fermeture de la fen�tre
    // Si on appelle m_open sur une fen�tre d�j� ouverte,
    // la fen�tre passe au premier plan

	    void     m_open();
	    void     m_close();

	    // ATTENTION : Ne pas utiliser en dehors du code des objets !
	    void     m_open_as_object_element(PObject object);


    // Modification du message d'information

	    void     m_set_info_message(const char *message);
	    const char *m_get_info_message();

    // M�thodes d'affichage dans la fen�tre

	    void     m_gotoxy(int x,int y);

	    unsigned m_get_normal_attr(unsigned background);
	    unsigned m_get_inverse_attr(unsigned background);
	    unsigned m_get_bright_attr(unsigned background);
	    unsigned m_get_inverse_bright_attr(unsigned background);
	    unsigned m_get_inactive_attr(unsigned background);
	    unsigned m_get_inverse_inactive_attr(unsigned background);

	    void     m_textattr(unsigned attribute);
	    void     m_set_normal_attr(unsigned background)           { m_textattr(m_get_normal_attr(background));};
	    void     m_set_inverse_attr(unsigned background)          { m_textattr(m_get_inverse_attr(background));};
	    void     m_set_bright_attr(unsigned background)           { m_textattr(m_get_bright_attr(background));};
	    void     m_set_inverse_bright_attr(unsigned background)   { m_textattr(m_get_inverse_bright_attr(background));};
	    void     m_set_inactive_attr(unsigned background)         { m_textattr(m_get_inactive_attr(background));};
	    void     m_set_inverse_inactive_attr(unsigned background) { m_textattr(m_get_inverse_inactive_attr(background));};

	    void     m_set_clip_window(int x,int y,int width,int height);
	    void     m_reset_clip_window();

	    void     m_cls(unsigned background);

	    void     m_putch(u_char character);
	    void     m_putnch(int nb_chars,u_char character);
	    void     m_puts(const char *string);

	    void     m_put_caption(const char *main_string, bool show_hot_key, int length, int position);
	    void     m_put_text(const char *text);
	    void     m_draw_frame(int x1,int y1,int x2,int y2,unsigned background, const char *caption, bool enabled);
	    void     m_display_arrow(int arrow_type);

	void	setCloseButtonPressedCallback(jptui::Callback& callback,
									  	  jptui::Callback::what_type what);
  /*--------------------*/
  /* M�thodes prot�g�es */
  /*--------------------*/

  protected:

    // Affichage

    virtual void     m_display();
    virtual void     m_display_focus_depending_part();
    virtual void     m_display_caption();
    virtual void     m_display_close_button(bool pressed);
    virtual void     m_display_info_bar();

    // Ev�nements

    virtual bool  m_left_button_pressed_event(int x,int y);
    virtual bool  m_key_pressed_event(TKey key);

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Manipulation des boutons sp�ciaux

	    void     m_set_ok_button(PPushButton button);
	    void     m_set_ok_button_to_default();
	    void     m_unset_ok_button();
	    void     m_button_destructed(PPushButton button);

    // Effacement de la fen�tre

    virtual void     m_clear();

    // Ajoute la fen�tre dans la zone d'�cran � rafra�chir

	    void     m_add_to_refresh_zone();

    // Ecriture directe � l'�cran

	    void     m_part_to_screen(int x1,int y1,int x2,int y2);
	    void     m_shadows_to_screen(int x1,int y1,int x2,int y2);

    // Ouverture/Fermeture de l'objet

    virtual void     m_set_open(bool open);

    // L'objet devient actif/inactif

    virtual void    m_set_active(bool active);

    // Ev�nements

	    bool  m_close_button_pressed_event();

};

#endif
