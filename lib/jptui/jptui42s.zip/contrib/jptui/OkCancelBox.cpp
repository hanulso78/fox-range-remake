#include "OkCancelBox.hpp"
#include "vocab.h"

using namespace jptui;

namespace jptui {

class OkCancelDs
{
public:
	OkCancelDs();
	const ButtonsBox::ButtonDescr*	ds() const;
private:
	ButtonsBox::ButtonDescr	ds_[3];
};

} // namespace jptui

OkCancelDs::OkCancelDs()
{
	ds_[0].title_ = GetString(VOC_OK_CAPTION);
	ds_[1].title_ = GetString(VOC_CANCEL_CAPTION);
	ds_[2].title_ = 0;
}

const ButtonsBox::ButtonDescr*	jptui::gOkCancelDs()
{
	static OkCancelDs d;
	return d.ds();
}

void	OkCancelBox::init(const char* title, size_t reserveX, size_t reserveY)
{
	ButtonsBox::init(title, DIALOG1, gOkCancelDs(), 0, 1, false, reserveX, reserveY);
}

const ButtonsBox::ButtonDescr*	jptui::OkCancelDs::ds() const
{
	return ds_;
}
