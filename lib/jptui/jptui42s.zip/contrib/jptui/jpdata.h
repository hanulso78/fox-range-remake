/****************************************************************************/
/* JPDATA                                                                   */
/*--------------------------------------------------------------------------*/
/* JPTUI Data Access Functions                                              */
/****************************************************************************/

#ifndef JPDATA_H_
#define JPDATA_H_

// Allocates a buffer and loads a data file into this buffer.
// This buffer must be freed by delete [].
// Returns a pointer to the buffer or NULL if an error occurs
// (no data file or incorrect data file).
// file_name must be at most 12 characters length

void LoadDataFile(const char *file_name, char *&buffer, long& size);

// Returns the message "Data file is invalid or missing"
// in the current language

const char *GetInvalidDataFileMessage();

#endif
