sxmlc
=====

Simple, lightweight XML parser in C.

Documentation on http://sxmlc.sourceforge.net/
