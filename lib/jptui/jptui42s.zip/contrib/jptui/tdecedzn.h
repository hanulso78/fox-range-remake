/****************************************************************************/
/* TDECEDZN                                                                 */
/*--------------------------------------------------------------------------*/
/* Objet TDecimalEditZone (Zone d'�dition d'un nombre d�cimal)              */
/****************************************************************************/

#ifndef _TDECEDZN_H_
#define _TDECEDZN_H_

#include <values.h>

#include "Types.h"

#include "TEdZone.h"

class TDecimalEditZone:public TEditZone
{
  /*---------------*/
  /* Champs priv�s */
  /*---------------*/

    // Valeurs limites autoris�es

    double  f_min_value,
	    f_max_value;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		    TDecimalEditZone(PObject parent,
				     int rel_x, int rel_y,
				     int xoffset_caption, int yoffset_caption,
				     const char *caption,
				     int display_length,
				     int max_length,
				     double min_value=-MAXDOUBLE,double max_value=MAXDOUBLE,
				     const char *string = "0",
				     bool enabled=true);

    virtual         ~TDecimalEditZone();

            void    m_set_min_max_values(double min_value,double max_value);

            double  m_get_min_value() {return(f_min_value);};
            double  m_get_max_value() {return(f_min_value);};

    // Validit� d'une cha�ne pour la zone

    virtual bool m_string_valid(const char *string);

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Validit� de la saisie

    virtual bool m_character_valid(int character);
    virtual const char *m_get_error_message();

};

#endif
