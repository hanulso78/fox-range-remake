JPTUI Quick Start
=================

To compile the demo :
- go to the DEMO directory
- type MAKEDEMO

To read the documentation :
- go to the DOCS directory
- type JPDOC
