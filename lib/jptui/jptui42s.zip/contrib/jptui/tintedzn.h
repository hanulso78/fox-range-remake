/****************************************************************************/
/* TINTEDZN                                                                 */
/*--------------------------------------------------------------------------*/
/* Objet TIntegerEditZone (Zone d'�dition d'un nombre entier)               */
/****************************************************************************/

#ifndef _TINTEDZN_H_
#define _TINTEDZN_H_

#include <values.h>
#include "Types.h"

#include "TEdZone.h"

class TIntegerEditZone:public TEditZone
{
  /*---------------*/
  /* Champs priv�s */
  /*---------------*/

   // Valeurs limites autoris�es

    long    f_min_value,
	    f_max_value;

  /*--------------------*/
  /* M�thodes publiques */
  /*--------------------*/

  public:

    // Constructeur / Destructeur

		    TIntegerEditZone(PObject parent,
				     int rel_x, int rel_y,
				     int xoffset_caption, int yoffset_caption,
				     const char *caption,
				     int display_length,
				     int max_length,
				     long min_value=-MAXLONG-1,long max_value=MAXLONG,
				     const char *string="0",
				     bool enabled=true);


    virtual         ~TIntegerEditZone();

            void    m_set_min_max_values(long min_value,long max_value);

            long    m_get_min_value() {return(f_min_value);};
            long    m_get_max_value() {return(f_min_value);};


    // Validit� d'une cha�ne pour la zone

    virtual bool m_string_valid(const char *string);

  /*------------------*/
  /* M�thodes priv�es */
  /*------------------*/

  private:

    // Validit� de la saisie

  private:
    virtual bool m_character_valid(int character);
    virtual const char *m_get_error_message();

};

#endif
