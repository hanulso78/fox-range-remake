#ifndef MNF_JPTUI_INPUT_BOX_HPP
#define MNF_JPTUI_INPUT_BOX_HPP

#include "OkCancelBox.hpp"
#include "tedzone.h"

namespace jptui {

class InputBox : public OkCancelBox
{
public:
	void	init(const char* title, const char* defaultString, 
			     size_t displayLength, size_t maxLength, 
				 bool passwordMode = false);
	const char*	getString() const;
private:
	std::auto_ptr<TEditZone>	editZone_;
};

} // namespace jptui

#endif//MNF_JPTUI_INPUT_BOX_HPP
