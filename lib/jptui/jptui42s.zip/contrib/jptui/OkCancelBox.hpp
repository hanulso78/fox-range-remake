#ifndef MNF_JPTUI_OK_CANCEL_BOX_HPP
#define MNF_JPTUI_OK_CANCEL_BOX_HPP

#include "ButtonsBox.hpp"

namespace jptui {

class OkCancelBox : public ButtonsBox
{
public:
	void	init(const char* title,	size_t reserveX, size_t reserveY);
};

extern const ButtonsBox::ButtonDescr*	gOkCancelDs();

} // namespace jptui

#endif//MNF_JPTUI_OK_CANCEL_BOX_HPP
